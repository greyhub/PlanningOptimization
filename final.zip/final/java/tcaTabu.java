import java.io.File;
import java.util.Scanner;

import localsearch.applications.CSP;
import localsearch.model.ConstraintSystem;
import localsearch.model.LocalSearchManager;
import localsearch.model.VarIntLS;
import localsearch.search.TabuSearch;

public class tcaTabu {
    int N, M, k;
    float[] d;
    float[] t;
    int[] j;
    int[][] D, c;
    float test;

    LocalSearchManager mgr;
    VarIntLS[][] x;
    ConstraintSystem CS;
    
    private void stateModel() {
        input("/home/luong/Documents/hust/toi-uu-lap-ke-hoach/final/data-bca/input/1.txt");
        // mgr = new LocalSearchManager();
        
        // // Bien

        // CS = new ConstraintSystem(mgr);

        // // Rang buoc
        
        // mgr.close();
    }

    private void search() {
        // TabuSearch ts = new TabuSearch();
        // ts.search(CS, 20, 10000, 20000, 100);

        // Print solution
    }

    public void solve() {
        stateModel();
        search();
    }

    private void input(String file_name) {
        try {
            System.out.println("Reading...");
            File f = new File(file_name);
            Scanner scanner = new Scanner(f);


            
            N = scanner.nextInt();
            M = scanner.nextInt();
            System.out.println(N + " " + M);

            d = new float[N];
            t = new float[N];
            D = new int[N][M];
            c = new int[N][N];


            for (int i=0; i<N; i++) {
                d[i] = scanner.nextFloat();
            }

            for (int i=0; i<M; i++) {
                t[i] = scanner.nextFloat();
            }

            for (int i=0; i<N; i++) {
                // j = new int[M];
                k = scanner.nextInt();
                for (int i1=0; i1<k; i1++) {
                    D[i][i1] = scanner.nextInt();
                }
                // D[i] = j;
            }

            for (int i=0; i<N; i++) {
                // j = new int[N];
                for (int i1=0; i1<N; i1++) {
                    c[i][i1] = scanner.nextInt();
                }
                // c[i] = j;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        final long startTime = System.currentTimeMillis();

        tcaTabu app = new tcaTabu();
        app.solve();
        
        final long duration = System.currentTimeMillis() - startTime;
        long minutes = (duration / 1000) / 60;
        long seconds  = (duration / 1000) % 60;
        System.out.println("\n" + minutes + "phút " + seconds + "s");
    }
}
