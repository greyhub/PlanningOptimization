package localsearch.domainspecific.vehiclerouting.vrp.enums;

public enum PointType {
	STARTING_ROUTE,
	TERMINATING_ROUTE,
	CLIENT
}
