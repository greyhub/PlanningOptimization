package localsearch.domainspecific.vehiclerouting.vrp.online.app;

public enum RequestType {
	PEOPLE_REQUEST,
	PARCEL_REQUEST
}
