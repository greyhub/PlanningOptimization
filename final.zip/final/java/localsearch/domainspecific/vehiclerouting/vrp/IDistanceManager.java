package localsearch.domainspecific.vehiclerouting.vrp;

import localsearch.domainspecific.vehiclerouting.vrp.entities.*;
public interface IDistanceManager {
	public double getDistance(Point x, Point y);
}
