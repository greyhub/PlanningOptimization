from ortools.linear_solver import pywraplp
import time
from time import gmtime, strftime

def main(name='20173249-1'):

    res = open(name+'-out.txt', 'w')

    solver = pywraplp.Solver.CreateSolver('SCIP')

    # ---- Bien ----
    x = {}
    for i in range(N):
        for j in range(M):
            x[i*M+j] = solver.IntVar(0, 1, 'x[{0},{1}]'.format(i,j))

    # ---- Rang buoc ----
    # 1. Moi lop chi mot giao vien
    for i in range(N):
        ct = solver.Constraint(0, 1)
        for j in range(M):
            ct.SetCoefficient(x[i*M+j],1)

    # 2. Giao vien hop le
    for i in range(N):
        ct = solver.Constraint(0, 0)
        for j in range(M):
          if j not in D[i]:
            ct.SetCoefficient(x[i*M+j], 1)

    # 3. Trung thoi khoa bieu
    for i1 in range(0, N-1):
        for i2 in range(i1+1, N):
            if c[i1][i2] == 1:
                for j in range(M):
                    ct = solver.Constraint(0, 1)
                    ct.SetCoefficient(x[i1*M+j],1)
                    ct.SetCoefficient(x[i2*M+j],1)

    # 4. Thoi luong day
    infinity = solver.infinity()
    for j in range(M):
        temp_t = t[j]
        T = solver.NumVar(temp_t, temp_t, 't')
        ct = solver.Constraint(-infinity, 0)
        for i in range(N):
            ct.SetCoefficient(x[i*M+j], d[i])
        ct.SetCoefficient(T, -1)

    # ---- Muc tieu ----
    y = 0
    for i in range(N):
        for j in range(M):
            y += x[i*M+j]
    solver.Maximize(y)
    # solver.SetTimeLimit(7000)

    # ---- Solver ----
    status = solver.Solve()
    if status == pywraplp.Solver.OPTIMAL:
        print('\nSolution:')
        count = 0
        for i in range(N):
            teacher = -1
            for j in range(M):
                if(x[i*M+j].solution_value() == 1):
                    teacher = j
            if teacher == -1:
                print(i, teacher)
                res.write(str(i)+' '+str(teacher))
                res.write('\n')
            else:
                print(i, teacher)
                count += 1
                res.write(str(i)+' '+str(teacher))
                res.write('\n')
        print(count)
        res.write(str(count))

    res.close()


def read_data(name='/content/drive/MyDrive/HUST/20202/Tối ưu lập kế hoạch/final/data-bca/input/200'):

    data = open(name+'.txt', 'r')
    global N, M, d, t, k, D, c
    d, t, D, c = [], [], [], []

    # Line 1: N M
    line_raw = data.readline().split('\n')
    line = line_raw[0].split(' ')
    N = int(line[0])
    M = int(line[1])
    print(N, M)

    # Line 2: d(0), d(1) ..., d(n-1)
    line_raw = data.readline().split('\n')
    line = line_raw[0].split(' ')
    for i in range(N):
        d.append(float(line[i]))
    #     print(d[i], end=' ')
    # print()

    # Line 3: t(0) ..., t(m-1)
    line_raw = data.readline().split('\n')
    line = line_raw[0].split(' ')
    for i in range(M):
        t.append(float(line[i]))
    #     print(t[i], end=' ')
    # print()

    # Line i+4: k j(1) ... j(k)
    for i in range(N):
        j = []
        line_raw = data.readline().split('\n')
        line = line_raw[0].split(' ')
        k = int(line[0])
        for i in range(k):
            j.append(int(line[i+1]))
        # print(j)
        D.append(j)
    # print(D)

    # Line n+i+4: c[i]
    for i in range(N):
        line_raw = data.readline().split('\n')
        line = line_raw[0].split(' ')
        temp_c = []
        for i in range(N):
            temp_c.append(int(line[i]))
        c.append(temp_c)
    # print(c)

    data.close()

def checktc(c4t=[], i=0, count=0):
    idx_t = sorted(range(len(t)), key=lambda k: t[k], reverse=True)
    for j in idx_t:
        if j in D[i]:
            if len(c4t[j]) > 1:
                for check in c4t[j]:
                    if c[check][i] == 0:
                        if t[j] >= d[i]:
                            teacher = j
                            t[j] -= d[i]
                            c4t[j].append(i)
                            return teacher
            else:
                if t[j] >= d[i]:
                    teacher = j
                    t[j] -= d[i]
                    c4t[j].append(i)
                    return teacher

def greedy(name='20173249-1'):
    
    res = open(name+'-out.txt', 'w')
    print('\nSolution:')
    c4t = []
    count = 0
    for j in range(M):
      c4t.append([-1])
    
    idx_c = sorted(range(len(d)), key=lambda k: d[k])
    val = sorted(d)

    for i in range(N):
        teacher = checktc(c4t, i, count)
        if teacher != None:
          count += 1
        else:
          teacher = -1
        print(i, teacher)
        res.write(str(i)+' '+str(teacher))
        res.write('\n')
    print(count)
    res.write(str(count))
    res.close()

if __name__ == '__main__':
    
    start = time.time()

    name = '/content/drive/MyDrive/HUST/20202/Tối ưu lập kế hoạch/final/data-bca/input/500'
    read_data(name)
    if N < 200:
      main(name)
    else:
      greedy(name)
    
    end = time.time()
    run_time = end - start
    if run_time < 20:
        print(round(run_time * 1000), 'ms')
    elif run_time < 30:
        print(round(run_time), 's')
    else:
        print(strftime("%H:%M:%S", gmtime(run_time)))
